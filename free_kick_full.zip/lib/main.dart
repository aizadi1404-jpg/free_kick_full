import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import 'src/game/free_kick_game.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FreeKickApp());
}

class FreeKickApp extends StatelessWidget {
  const FreeKickApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Free Kick Stadium',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const FreeKickGamePage(),
    );
  }
}

class FreeKickGamePage extends StatelessWidget {
  const FreeKickGamePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GameWidget(game: FreeKickGame()),
        ],
      ),
    );
  }
}
