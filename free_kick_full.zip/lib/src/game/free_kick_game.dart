import 'dart:math';

import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

class FreeKickGame extends FlameGame with PanDetector, HasCollisionDetection {
  late final CameraComponent _camera;
  late final TextComponent _scoreText;
  int _score = 0;

  late final Ball _ball;
  late final Goal _goal;
  late final Keeper _keeper;
  late final Wall _wall;

  final Vector2 fieldSize = Vector2(360, 640);

  @override
  Color backgroundColor() => const Color(0xFF0B3D02); // سبز تیره پس زمینه دور استادیوم

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    camera.viewport = FixedResolutionViewport(fieldSize);

    // زمین چمن
    add(RectangleComponent(
      position: Vector2.zero(),
      size: fieldSize,
      paint: Paint()..color = const Color(0xFF2ECC71),
    ));

    // دروازه
    _goal = Goal(fieldSize);
    add(_goal);

    // دیوار دفاعی
    _wall = Wall(fieldSize);
    add(_wall);

    // دروازه‌بان
    _keeper = Keeper(fieldSize);
    add(_keeper);

    // توپ
    _resetBall();

    // امتیاز
    _scoreText = TextComponent(
      text: 'Score: 0',
      position: Vector2(10, 10),
      anchor: Anchor.topLeft,
      priority: 10,
      textRenderer: TextPaint(
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
    add(_scoreText);
  }

  void _resetBall() {
    _ball = Ball(
      position: Vector2(fieldSize.x / 2, fieldSize.y - 80),
    );
    add(_ball);
  }

  @override
  void onPanEnd(DragEndInfo info) {
    super.onPanEnd(info);
    if (_ball.hasKicked) return;

    final velocity = info.velocity.global;

    final vx = (velocity.x / 8).clamp(-400.0, 400.0);
    final vy = (-velocity.y / 10).clamp(-900.0, -300.0);

    // کمی انحنا بر اساس جهت افقی سوایپ
    final curve = (vx / 400) * 0.5; // بین -0.5 تا 0.5

    _ball.kick(Vector2(vx.toDouble(), vy.toDouble()), curve);
  }

  void onGoal() {
    _score += 1;
    _scoreText.text = 'Score: '$_score'';
    _showFloatingText('GOAL!');
    _nextRound();
  }

  void onMiss() {
    _showFloatingText('MISS');
    _nextRound();
  }

  void _nextRound() {
    _ball.removeFromParent();
    _keeper.randomizeTarget();
    _wall.randomizeWall();
    Future.delayed(const Duration(milliseconds: 600), _resetBall);
  }

  void _showFloatingText(String text) {
    final floating = TextComponent(
      text: text,
      anchor: Anchor.center,
      position: Vector2(fieldSize.x / 2, fieldSize.y / 2),
      textRenderer: TextPaint(
        style: const TextStyle(
          color: Colors.white,
          fontSize: 32,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
    add(floating);
    floating.add(OpacityEffect.to(
      0,
      EffectController(duration: 0.6),
      onComplete: () => floating.removeFromParent(),
    ));
  }
}

class Ball extends CircleComponent with HasGameRef<FreeKickGame> {
  bool hasKicked = false;
  late Vector2 _velocity;
  double _curve = 0;

  Ball({required Vector2 position}) : super(
    radius: 14,
    position: position,
    anchor: Anchor.center,
  ) {
    paint = Paint()..color = const Color(0xFFFFFFFF);
  }

  void kick(Vector2 initialVelocity, double curve) {
    hasKicked = true;
    _velocity = initialVelocity;
    _curve = curve;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!hasKicked) return;

    // انحنا در جهت X
    _velocity.x += _curve * 40 * dt;

    // گرانش سبک
    _velocity.y += 10 * dt;

    position += _velocity * dt;

    if (position.y < 50 || position.y > gameRef.fieldSize.y + 40) {
      gameRef.onMiss();
    }

    // بررسی گل شدن
    if (position.y < 120 &&
        position.x > gameRef.fieldSize.x / 2 - 60 &&
        position.x < gameRef.fieldSize.x / 2 + 60) {
      gameRef.onGoal();
    }
  }
}

class Goal extends PositionComponent {
  Goal(Vector2 fieldSize) : super(
    position: Vector2(fieldSize.x / 2, 80),
    size: Vector2(140, 20),
    anchor: Anchor.center,
  );

  @override
  void render(Canvas canvas) {
    final paint = Paint()
      ..color = const Color(0xFFFFFFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final rect = Rect.fromCenter(
      center: Offset(size.x / 2, size.y / 2),
      width: size.x,
      height: size.y,
    );

    canvas.drawRect(rect, paint);
  }
}

class Keeper extends PositionComponent with HasGameRef<FreeKickGame> {
  final Random _random = Random();
  double _targetX = 0;
  double _speed = 220;

  Keeper(Vector2 fieldSize) : super(
    position: Vector2(fieldSize.x / 2, 100),
    size: Vector2(40, 40),
    anchor: Anchor.center,
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    randomizeTarget();
  }

  void randomizeTarget() {
    final left = gameRef.fieldSize.x / 2 - 50;
    final right = gameRef.fieldSize.x / 2 + 50;
    _targetX = left + _random.nextDouble() * (right - left);
  }

  @override
  void update(double dt) {
    super.update(dt);
    final dx = _targetX - position.x;
    if (dx.abs() < 2) return;
    position.x += dx.sign * _speed * dt;
  }

  @override
  void render(Canvas canvas) {
    final bodyPaint = Paint()..color = const Color(0xFF3498DB);
    final headPaint = Paint()..color = const Color(0xFFFFE0BD);

    // بدن
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.x / 2 - 15, size.y / 2 - 15, 30, 30),
        const Radius.circular(6),
      ),
      bodyPaint,
    );

    // سر
    canvas.drawCircle(
      Offset(size.x / 2, size.y / 2 - 22),
      8,
      headPaint,
    );
  }
}

class Wall extends PositionComponent with HasGameRef<FreeKickGame> {
  final Random _random = Random();
  int _count = 3;

  Wall(Vector2 fieldSize) : super(
    position: Vector2(fieldSize.x / 2, 180),
    size: Vector2(90, 40),
    anchor: Anchor.center,
  );

  void randomizeWall() {
    _count = 2 + _random.nextInt(2); // 2 یا 3 نفر
  }

  @override
  void render(Canvas canvas) {
    final bodyPaint = Paint()..color = const Color(0xFFE74C3C);
    final headPaint = Paint()..color = const Color(0xFFFFE0BD);

    final spacing = size.x / _count;

    for (int i = 0; i < _count; i++) {
      final cx = spacing * (i + 0.5);

      // بدن
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(cx - 12, size.y / 2 - 18, 24, 30),
          const Radius.circular(6),
        ),
        bodyPaint,
      );

      // سر
      canvas.drawCircle(
        Offset(cx, size.y / 2 - 24),
        7,
        headPaint,
      );
    }
  }
}
